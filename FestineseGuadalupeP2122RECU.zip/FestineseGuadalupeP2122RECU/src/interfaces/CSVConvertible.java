
package interfaces;

public interface CSVConvertible {
    String toCSV();
}
