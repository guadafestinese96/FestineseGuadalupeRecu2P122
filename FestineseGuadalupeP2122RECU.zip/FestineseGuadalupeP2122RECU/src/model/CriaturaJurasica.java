package model;

import interfaces.CSVConvertible;
import java.io.IOException;
import java.io.Serializable;

public class CriaturaJurasica implements CSVConvertible, Comparable<CriaturaJurasica>, Serializable {

    private int id;
    private String nombre;
    private Especie especie;
    private int nivelPeligrosidad;
    private int anioDescubrimiento;

    public CriaturaJurasica(int id, String nombre, Especie especie, int nivelPeligrosidad, int anioDescubrimiento) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.nivelPeligrosidad = nivelPeligrosidad;
        this.anioDescubrimiento = anioDescubrimiento;
    }

    @Override
    public String toString() {
        return "CriaturaJurasica{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", nivelPeligrosidad=" + nivelPeligrosidad + ", anioDescubrimiento=" + anioDescubrimiento + '}';
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Especie getEspecie() {
        return especie;
    }

    public int getNivelPeligrosidad() {
        return nivelPeligrosidad;
    }

    public void setNivelPeligrosidad(int nivelASumar) {
        nivelPeligrosidad += nivelASumar;
    }

    public int getAnioDescubrimiento() {
        return anioDescubrimiento;
    }

    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + nivelPeligrosidad + "," + anioDescubrimiento;
    }

    public static String toHeaderCSV() {
        return "id,nombre,especie,nivelPeligrosidad,anioDescubribimiento";
    }

    public static CriaturaJurasica fromCSV(String linea) {
        String[] datos = linea.split(",");
        return new CriaturaJurasica(
                Integer.parseInt(datos[0]),
                datos[1],
                Especie.valueOf(datos[2]),
                Integer.parseInt(datos[3]),
                Integer.parseInt(datos[4])
        );
    }

    @Override
    public int compareTo(CriaturaJurasica cj) {
        int cmp = Integer.compare(cj.nivelPeligrosidad, this.nivelPeligrosidad);
        if (cmp != 0) {
            return cmp;
        }
        return Integer.compare(this.anioDescubrimiento, cj.anioDescubrimiento);
    }
}
