package model;

import interfaces.Almacenable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T> implements Almacenable {

    List<T> lista = new ArrayList<>();

    @Override
    public void agregar(Object elemento) {
        lista.add((T) elemento);

    }

    @Override
    public void eliminarSegun(Predicate criterio) {
        
    }

    @Override
    public List obtenerTodos() {
        List<T> listaCopy = new ArrayList<>();
        for (T elem : lista) {
            listaCopy.add(elem);
        }
        return listaCopy;
    }

    @Override
    public Object buscar(Predicate criterio) {
        return null;
    }

    @Override
    public void ordenar() {
          lista.sort(null);
    }

    @Override
    public void ordenar(Comparator comparador) {
        lista.sort(comparador);
    }

    @Override
    public List filtrar(Predicate criterio) {
         List<T> listaFiltrada = new ArrayList<>();
        for (T p : lista) {
            if (criterio.test(p)) {
                listaFiltrada.add(p);
            }
        }
        return listaFiltrada;
    }

    @Override
    public List transformar(Function operador) {
        List<T> listaTransformada = new ArrayList<>();
        for(T elem : lista){
            if(elem instanceof CriaturaJurasica cj){
                if(cj.getEspecie().equals("VELOCIRAPTOR")){
                    if(cj.getNivelPeligrosidad() < 10){
                        cj.setNivelPeligrosidad(1);
                    }
                }
                listaTransformada.add(elem);
            }
        }
        return listaTransformada;
    }

    @Override
    public int contar(Predicate criterio) {
        int contador = 0;
        for(T elem : lista){
            if(criterio.test(elem)){
                contador++;
            }
        }
        
        return contador;
    }
    

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
         try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(ruta))) {
            salida.writeObject(lista);        
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        List<T> toReturn = null;
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(ruta))) {
            toReturn = (List<T>) entrada.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } 
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            escritor.write(CriaturaJurasica.toHeaderCSV());
            escritor.newLine();

            for (T elem : lista) {
                CriaturaJurasica cj = (CriaturaJurasica) elem;
                escritor.write(cj.toCSV());
                escritor.newLine();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function fromCSV) throws Exception {
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            lector.readLine();
            String linea;
            while ((linea = lector.readLine()) != null) {
                lista.add((T)CriaturaJurasica.fromCSV(linea));
            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    @Override
    public void guardarEnJSON(String ruta) throws Exception {

    }
}
